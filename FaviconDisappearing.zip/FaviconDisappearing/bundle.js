const Bundler = require("parcel-bundler");
const Path = require("path");

(async function () {
  await new Bundler(Path.join(__dirname, "./src/index.html"), {
    publicUrl: "/",
    watch: true,
    cache: false,
  }).serve(9966, false, "localhost");
})();
