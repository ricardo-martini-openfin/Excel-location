(() => {
  async function updateWindowOptions() {
    const openFinWindow = await fin.Window.getCurrent();
    await openFinWindow.updateOptions({
      frame: true,
    });
  }

  setTimeout(updateWindowOptions,5000);
})();
